package edu.ncsu.csc450.contextmiddleware;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.RemoteException;

/**
 * Created by Tsu on 10/31/16.
 * This class is used to create and manage light sensor used for the application and provide getter
 * method to have access to the value. The class is also responsible to update the label showing
 * the light sensor value.
 */
public class MySensorManager {

    private SensorManager sensorManager;
    private Sensor lightSensor;
    private Context context;
    private boolean prevValue = false;

    // The listener to light
    private SensorEventListener lightListener = new SensorEventListener() {
        public void onSensorChanged(SensorEvent event) {
            ContextMiddlewareService.lightValue = (int)event.values[0];
            try{
                if(ContextMiddlewareService.getEnvironmentUpdates){
                    if(ContextMiddlewareService.lightValue <= 10 && !prevValue){
                        prevValue = true;
                        ContextMiddlewareService.environmentUpdateCallback.updateUserContextCallback(prevValue);
                    }else if(ContextMiddlewareService.lightValue > 10 && prevValue){
                        prevValue = false;
                        ContextMiddlewareService.environmentUpdateCallback.updateUserContextCallback(prevValue);
                    }
                }
            }catch(RemoteException e){

            }


        }

        public void onAccuracyChanged(Sensor sensor, int acc) {}
    };

    public MySensorManager(Context context){
        this.context = context;
        sensorManager = (SensorManager) this.context.getSystemService(Context.SENSOR_SERVICE);
        this.lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
    }

    public SensorManager getSensorManager(){
        return this.sensorManager;
    }

    public Sensor getLightSensor(){
        return this.lightSensor;
    }

    public SensorEventListener getLightListener(){
        return this.lightListener;
    }
}
