package edu.ncsu.csc450.contextmiddleware;

/**
 * Created by mf3791 on 11/17/16.
 */
import android.app.Activity;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;


public class MainActivity extends Activity{

    /** Called when the activity is first created. */


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


}
