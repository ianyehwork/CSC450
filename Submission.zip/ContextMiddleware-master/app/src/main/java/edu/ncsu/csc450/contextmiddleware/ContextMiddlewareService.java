package edu.ncsu.csc450.contextmiddleware;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

public class ContextMiddlewareService extends Service {
    boolean getLocationUpdates = false;
    public static boolean getEnvironmentUpdates = false;
    public static IContextCallback environmentUpdateCallback, locationUpdateCallback;
    private static final String TAG = "TESTGPS";
    private LocationManager mLocationManager = null;
    private static final int LOCATION_INTERVAL = 1000;
    private static final float LOCATION_DISTANCE = 10f;

    // light sensor
    private MySensorManager mySensorManager;
    public static int lightValue = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.e(TAG, "onCreate");
        initializeLocationManager();
        initializeSensorManager();

        try {
            mLocationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER, LOCATION_INTERVAL, LOCATION_DISTANCE,
                    mLocationListeners[1]);
        } catch (java.lang.SecurityException ex) {
            Log.i(TAG, "Failed to request location update, ignore", ex);
        } catch (IllegalArgumentException ex) {
            Log.d(TAG, "Network provider does not exist, " + ex.getMessage());
        }
        try {
            mLocationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER, LOCATION_INTERVAL, LOCATION_DISTANCE,
                    mLocationListeners[0]);
        } catch (java.lang.SecurityException ex) {
            Log.i(TAG, "Failed to request location update, ignore", ex);
        } catch (IllegalArgumentException ex) {
            Log.d(TAG, "GPS provider does not exist " + ex.getMessage());
        }

    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.d("IRemote", "Bind Carrem");
        return mBinder;
    }

    @Override
    public void onDestroy() {
        Log.e(TAG, "onDestroy");
        super.onDestroy();
        if (mLocationManager != null) {
            for (int i = 0; i < mLocationListeners.length; i++) {
                try {
                    mLocationManager.removeUpdates(mLocationListeners[i]);
                } catch (SecurityException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void initializeLocationManager() {
        Log.e(TAG, "initializeLocationManager");
        if (mLocationManager == null) {
            mLocationManager = (LocationManager) getApplicationContext().getSystemService(Context.LOCATION_SERVICE);
        }
    }

    private void initializeSensorManager(){
        mySensorManager = new MySensorManager(getApplicationContext());
        mySensorManager.getSensorManager().registerListener(mySensorManager.getLightListener(), mySensorManager.getLightSensor(), SensorManager.SENSOR_DELAY_NORMAL);
        mySensorManager.getSensorManager().registerListener(mySensorManager.getLightListener(), mySensorManager.getLightSensor(), SensorManager.SENSOR_DELAY_NORMAL);
    }

    private class LocationListener implements android.location.LocationListener {
        Location mLastLocation;

        public LocationListener(String provider) {
            Log.e(TAG, "LocationListener " + provider);
            mLastLocation = new Location(provider);
        }

        @Override
        public void onLocationChanged(Location location) {
            Log.e(TAG, "onLocationChanged: " + location);
            mLastLocation.set(location);
            try {
                if (location != null) {
                    if (getLocationUpdates) {
                        /*
                         * The callback function called here is implemented in the client application. The data sent back can be
                         * handled appropriately by changing the implementation on the application.
                         */
                        locationUpdateCallback.updateLocationCallback(Double.toString(location.getLatitude()), Double.toString(location.getLongitude()));
                    }

                }
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onProviderDisabled(String provider) {
            Log.e(TAG, "onProviderDisabled: " + provider);
        }

        @Override
        public void onProviderEnabled(String provider) {
            Log.e(TAG, "onProviderEnabled: " + provider);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            Log.e(TAG, "onStatusChanged: " + provider);
        }
    }

    /*
     * Initializing listeners for GPS and NetwoL
     * rk
     */
    LocationListener[] mLocationListeners = new LocationListener[]{
            new LocationListener(LocationManager.GPS_PROVIDER),
            new LocationListener(LocationManager.NETWORK_PROVIDER)
    };

    /*
    *   Implement functions in the interface.
    *   Since some functions and/or variables of the superclass might be required, it is better to call an external function from
    *   the interface.
     */
    private final IContextInterface.Stub mBinder = new IContextInterface.Stub() {

        /*
         * The void functions are asynchronous. Once these functions have been called, the Service completes execution and uses
         * the callback interface to communicate with the application.
         */
        public void registerForLocationUpdates(final IContextCallback callback) throws RemoteException {
            enableLocationUpdate(callback);
        }

        public void registerForEnvironmentUpdates(final IContextCallback callback) throws RemoteException{
            enableEnvironmentUpdates(callback);
        }



    };

    /*
     * enableLocationUpdate and enableEnvironmentUpdates are used to set the flags and the callbacks.
     */
    void enableLocationUpdate(IContextCallback tCallback) {
        this.getLocationUpdates = true;
        this.locationUpdateCallback = tCallback;
    }

    void enableEnvironmentUpdates(IContextCallback tCallback) {
        this.getEnvironmentUpdates = true;
        this.environmentUpdateCallback = tCallback;
    }



}
